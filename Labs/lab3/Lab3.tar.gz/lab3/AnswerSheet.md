## 任务答题卡
### 任务一 文件配对
**Q1:task0.c对应哪个.ihx文件呢**
- [ ] maomao.ihx
- [ ] miaomiao.ihx
- [ ] wangwang.ihx

**Q2:task1.c对应哪个.ihx文件呢**
- [ ] maomao.ihx
- [ ] miaomiao.ihx
- [ ] wangwang.ihx

**Q3:task2.c对应哪个.ihx文件呢**
- [ ] maomao.ihx
- [ ] miaomiao.ihx
- [ ] wangwang.ihx

### 任务二 完善呼吸灯
**Q4:请把代码输入到代码框中**(C语言代码和编译生成的十六进制数据都粘帖上来吧)

**这里是C语言代码**
```c

```

**这里是编译产生的十六进制数据**
```hex

```