#include "zuma.h"

void delete(zuma *node);
void insert(zuma *node, zuma *new_node);
