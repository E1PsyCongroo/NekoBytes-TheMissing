#include "8052.h"

#define LED P2_0

unsigned char cnt = 0;

int flag = 1;

void main()
{
	LED = 0;
	while(1)
	{
		unsigned char i = 0;
		LED=!LED;
		for(i = 0;i<cnt;i++);
		cnt+=flag;
		LED=!LED;
		i = 0;
		for(i = 0;i<255-cnt;i++);
		
		if(cnt==255){
			flag = -1;
		}else if(cnt == 0){
			flag = 1;
		}

	}

}
