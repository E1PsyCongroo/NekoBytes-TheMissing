## 任务答题卡
### 任务一 文件配对
**Q1:task0.c对应哪个.ihx文件呢**
- [x] maomao.ihx
- [ ] miaomiao.ihx
- [ ] wangwang.ihx

**Q2:task1.c对应哪个.ihx文件呢**
- [ ] maomao.ihx
- [x] miaomiao.ihx
- [ ] wangwang.ihx

**Q3:task2.c对应哪个.ihx文件呢**
- [ ] maomao.ihx
- [ ] miaomiao.ihx
- [x] wangwang.ihx

### 任务二 完善呼吸灯
**Q4:请把代码输入到代码框中**(C语言代码和编译生成的十六进制数据都粘帖上来吧)

**这里是C语言代码**
```c
#include "8052.h"

#define LED P2_0

unsigned char cnt = 0;

int flag = 1;

void main()
{
	LED = 0;
	while(1)
	{
		unsigned char i = 0;
		LED=!LED;
		for(i = 0;i<cnt;i++);
		cnt+=flag;
		LED=!LED;
		i = 0;
		for(i = 0;i<255-cnt;i++);
		
		if(cnt==255){
			flag = -1;
		}else if(cnt == 0){
			flag = 1;
		}

	}

}
```

**这里是编译产生的十六进制数据**
```hex
:03000000020006F5
:0C005F00750800750901750A0002000315
:0300030002006B8D
:20006B00C2A0B2A07F00C3EF950850030F80F7AF09AE08EF2EF508B2A07F00AD087E00741A
:20008B00FFC39DFDE49EFE8F037C00C3EB9DEC64808EF063F08095F050030F80DE74FFB592
:1500AB0008087509FF750AFF80B8E50870B4750901F50A80AD41
:06003500E478FFF6D8FD9F
:200013007900E94400601B7A009000C4780175A000E493F2A308B8000205A0D9F4DAF275CF
:02003300A0FF2C
:20003B007800E84400600A790175A000E4F309D8FC7800E84400600C7900900001E4F0A3C3
:04005B00D8FCD9FAFA
:0D00060075810A1200C0E58260030200034C
:0400C0007582002223
:00000001FF
```
