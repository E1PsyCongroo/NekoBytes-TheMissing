#ifndef __ECHO__H
#define __ECHO__H
void echo(int argc, char *argv[]);
#endif
