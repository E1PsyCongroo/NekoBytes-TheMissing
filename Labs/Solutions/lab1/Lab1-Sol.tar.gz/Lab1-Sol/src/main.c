#include "echo/echo.h"

int main(int argc, char *argv[]) {
  echo(argc, argv);
  return 0;
}
