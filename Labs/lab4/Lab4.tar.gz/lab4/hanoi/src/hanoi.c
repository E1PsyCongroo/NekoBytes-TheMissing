#include "hanoi.h"

/* 用于将大小为plate的盘子从from柱移动到to柱 */
void tower_move(int plate, char from, char to);

void hanoi(int n, char from, char to, char spare) {
  // TODO
  return;
}
