#include <stdio.h>

void echo(int argc, char *argv[]);