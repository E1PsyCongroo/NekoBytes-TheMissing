/*Create by YJS*/

#ifndef PERCEPTRON_H
#define PERCEPTRON_H


typedef struct Dim {
    int h; // 高度
    int w; // 宽度
} Dim;

// 定义层结构体，表示神经网络中的一层
typedef struct layer {
    Dim dim;         // 层的维度
    float** weight;  // 层的权重矩阵
    float* biases;   // 层的偏置向量
    float* input;    // 层的输入向量
    float* output;   // 层的输出向量
    struct layer *next, *pre; // 指向下一层和前一层的指针
} layer;

// 定义神经网络结构体，表示一个神经网络
typedef struct NeuralNet {
    layer *input;    // 指向输入层的指针
    layer *output;   // 指向输出层的指针
    float* prediction; // 神经网络的预测结果向量
} NeuralNet;

typedef float (*Activation) (float); //激活函数
typedef float (*ActivationDerivative)(float); // 激活函数的导数


layer* init_layer(int h);
void delete_layer(layer** n);
NeuralNet* init_NeuralNet(int input,int output);
void delete_NeuralNet(NeuralNet** n);
void connect(layer* pre,layer* next);
void add_hidden_layer(NeuralNet* neuralnet,int h);
void linear_regression_feed_forward(NeuralNet *ann, float *X,Activation f);
void classification_feed_forward(NeuralNet *ann, float *X, Activation f);
void train(NeuralNet *ann, float **X, float **y, int n_samples,int n_epoch,float learning_rate,Activation f,ActivationDerivative fd);





float dot_product(float *v, float *u, int n);
float sigmoid(float x);
float sigmoid_derivative(float x);
float ReLU_derivative(float x);
float ReLU(float x);
float tanh_(float x);
float tanh_derivative(float x);
float leakyReLU(float x);
float leakyReLU_derivative(float x);
float random_weight(int input_dim,int output_dim);
float mse_loss(float* y_true, float* y_pred, int size);
void backpropagation(NeuralNet* ann, float* input, float* y_true, float learning_rate, ActivationDerivative f);
float clip_gradients(float x);
void softmax(float* v,int size);
void test_loss(NeuralNet *ann,float **X, float **y,int n_samples,Activation f,int flag);
void linear_test_loss(NeuralNet *ann,float **X, float **y,int n_samples,Activation f,int flag);




void delete_csv_data(float*** data, int len);
float** read_csv(int start_row, int num_rows, int start_col, int num_cols, char* file_path);
int get_file_len(char* file_path);
void save_predictions_to_file(float **predictions,float** actual, int n_samples, int n_outputs, char* file_path);
void encode_category_to_vector(float** data,int category,int len);
void decode_vector_to_category(float** data, int num_category,int len);
int get_max_index(float* v,int num_category);
#endif // PERCEPTRON_H
